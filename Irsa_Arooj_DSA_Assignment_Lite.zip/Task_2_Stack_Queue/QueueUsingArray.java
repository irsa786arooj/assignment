import java.util.Scanner;
public class QueueUsingArray {
    int[] a=new int[5]; int front=0,rear=-1,size=0;
    void enqueue(int x){if(size==5)System.out.println("Full");else{rear=(rear+1)%5;a[rear]=x;size++;}}
    void dequeue(){if(size==0)System.out.println("Empty");else{System.out.println("Removed: "+a[front]);front=(front+1)%5;size--;}}
    void display(){for(int i=0;i<size;i++)System.out.print(a[(front+i)%5]+" ");System.out.println();}
    public static void main(String[] args){Scanner s=new Scanner(System.in);QueueUsingArray q=new QueueUsingArray();int c;
        do{System.out.println("1.Enqueue 2.Dequeue 3.Display 0.Exit");c=s.nextInt();
            if(c==1)q.enqueue(s.nextInt());else if(c==2)q.dequeue();else if(c==3)q.display();
        }while(c!=0);s.close();}
}
