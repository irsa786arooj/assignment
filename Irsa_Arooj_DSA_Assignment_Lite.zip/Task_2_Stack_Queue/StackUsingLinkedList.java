import java.util.Scanner;
public class StackUsingLinkedList {
    static class Node { int data; Node next; Node(int d){data=d;} }
    Node top;
    void push(int x){Node n=new Node(x); n.next=top; top=n;}
    void pop(){if(top==null) System.out.println("Underflow"); else {System.out.println("Popped: "+top.data); top=top.next;}}
    void display(){for(Node n=top;n!=null;n=n.next) System.out.print(n.data+" "); System.out.println();}
    public static void main(String[] args){
        Scanner s=new Scanner(System.in); StackUsingLinkedList st=new StackUsingLinkedList(); int c;
        do{System.out.println("1.Push 2.Pop 3.Display 0.Exit");c=s.nextInt();
            if(c==1)st.push(s.nextInt());else if(c==2)st.pop();else if(c==3)st.display();
        }while(c!=0);s.close();
    }
}
