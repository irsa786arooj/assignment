import java.util.Scanner;
public class StackUsingArray {
    int[] a = new int[5]; int top = -1;
    void push(int x) { if (top == 4) System.out.println("Overflow"); else a[++top] = x; }
    void pop() { if (top == -1) System.out.println("Underflow"); else System.out.println("Popped: " + a[top--]); }
    void display() { for (int i = top; i >= 0; i--) System.out.print(a[i] + " "); System.out.println(); }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in); StackUsingArray st = new StackUsingArray();
        int c; do { System.out.println("1.Push 2.Pop 3.Display 0.Exit"); c=s.nextInt();
            if(c==1) st.push(s.nextInt()); else if(c==2) st.pop(); else if(c==3) st.display();
        } while(c!=0); s.close();
    }
}
