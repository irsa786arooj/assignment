import java.util.Scanner;
public class QueueUsingLinkedList {
    static class Node{int data;Node next;Node(int d){data=d;}}
    Node front,rear;
    void enqueue(int x){Node n=new Node(x);if(rear==null)front=rear=n;else{rear.next=n;rear=n;}}
    void dequeue(){if(front==null)System.out.println("Empty");else{System.out.println("Removed: "+front.data);front=front.next;if(front==null)rear=null;}}
    void display(){for(Node n=front;n!=null;n=n.next)System.out.print(n.data+" ");System.out.println();}
    public static void main(String[] args){Scanner s=new Scanner(System.in);QueueUsingLinkedList q=new QueueUsingLinkedList();int c;
        do{System.out.println("1.Enqueue 2.Dequeue 3.Display 0.Exit");c=s.nextInt();
            if(c==1)q.enqueue(s.nextInt());else if(c==2)q.dequeue();else if(c==3)q.display();
        }while(c!=0);s.close();}
}
