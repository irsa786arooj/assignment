# Data Structures and Algorithms — Assignment

**Student:** Irsa Arooj  
**Instructor:** Sir Sabeeh  
**Language:** Java

## Contents
- Task 1: Array through a student-marks scenario
- Task 2: Stack using array and linked list; queue using array and linked list
- Assignment 1: Bubble, Selection, Insertion, and Merge Sort with pseudocode, dry runs, time complexities, and Java code

## Run a Java file
```bash
javac FileName.java
java ClassName
```
