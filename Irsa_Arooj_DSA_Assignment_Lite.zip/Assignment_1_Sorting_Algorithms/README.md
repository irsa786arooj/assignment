# Assignment No. 1 — Sorting Algorithms

## 1. Bubble Sort
**Algorithm:** Compare adjacent values; swap if left is greater. Repeat passes until sorted.

**Dry run** `[5,1,4,2]`:
- Pass 1: `[1,5,4,2]` → `[1,4,5,2]` → `[1,4,2,5]`
- Pass 2: `[1,4,2,5]` → `[1,2,4,5]`
- Pass 3: already sorted. Result: `[1,2,4,5]`

**Time:** Best `O(n)` with early-stop flag; average/worst `O(n²)`. Space `O(1)`.

## 2. Selection Sort
**Algorithm:** Find the minimum in the unsorted section and swap it into the next position.

**Dry run** `[5,1,4,2]`:
- Pass 1: minimum 1 → `[1,5,4,2]`
- Pass 2: minimum 2 → `[1,2,4,5]`
- Pass 3: minimum 4 → `[1,2,4,5]`

**Time:** Best/average/worst `O(n²)`. Space `O(1)`.

## 3. Insertion Sort
**Algorithm:** Take each next value and insert it into the correct place in the sorted left section.

**Dry run** `[5,1,4,2]`:
- Insert 1 → `[1,5,4,2]`
- Insert 4 → `[1,4,5,2]`
- Insert 2 → `[1,2,4,5]`

**Time:** Best `O(n)`; average/worst `O(n²)`. Space `O(1)`.

## 4. Merge Sort
**Algorithm:** Divide into halves until single elements remain, then merge in sorted order.

**Dry run** `[5,1,4,2]`:
- Split: `[5,1]`, `[4,2]`; then `[5]`, `[1]`, `[4]`, `[2]`
- Merge to `[1,5]` and `[2,4]`
- Final merge: `[1,2,4,5]`

**Time:** Best/average/worst `O(n log n)`. Space `O(n)`.

## Summary
| Sort | Best | Average | Worst | Extra space |
|---|---|---|---|---|
| Bubble (optimized) | O(n) | O(n²) | O(n²) | O(1) |
| Selection | O(n²) | O(n²) | O(n²) | O(1) |
| Insertion | O(n) | O(n²) | O(n²) | O(1) |
| Merge | O(n log n) | O(n log n) | O(n log n) | O(n) |

`O(1)` constant, `O(log n)` logarithmic, `O(n)` linear, `O(n log n)` efficient divide-and-conquer, `O(n²)` quadratic. If your teacher specified videos, add their URLs and any extra complexities covered.
