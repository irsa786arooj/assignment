import java.util.Arrays;
public class SortingAlgorithms {
    static void bubble(int[] a){for(int i=0;i<a.length-1;i++){boolean swap=false;for(int j=0;j<a.length-i-1;j++)if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;swap=true;}if(!swap)break;}}
    static void selection(int[] a){for(int i=0;i<a.length-1;i++){int m=i;for(int j=i+1;j<a.length;j++)if(a[j]<a[m])m=j;int t=a[i];a[i]=a[m];a[m]=t;}}
    static void insertion(int[] a){for(int i=1;i<a.length;i++){int key=a[i],j=i-1;while(j>=0&&a[j]>key){a[j+1]=a[j];j--;}a[j+1]=key;}}
    static void mergeSort(int[] a){if(a.length<2)return;int m=a.length/2;int[] l=Arrays.copyOfRange(a,0,m),r=Arrays.copyOfRange(a,m,a.length);mergeSort(l);mergeSort(r);int i=0,j=0,k=0;while(i<l.length&&j<r.length)a[k++]=l[i]<=r[j]?l[i++]:r[j++];while(i<l.length)a[k++]=l[i++];while(j<r.length)a[k++]=r[j++];}
    public static void main(String[] args){int[] original={5,1,4,2};int[] a=original.clone();bubble(a);System.out.println("Bubble: "+Arrays.toString(a));a=original.clone();selection(a);System.out.println("Selection: "+Arrays.toString(a));a=original.clone();insertion(a);System.out.println("Insertion: "+Arrays.toString(a));a=original.clone();mergeSort(a);System.out.println("Merge: "+Arrays.toString(a));}
}
