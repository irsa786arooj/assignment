import java.util.Scanner;

public class ArrayScenario {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] marks = new int[5];
        int total = 0;

        System.out.println("Enter marks of 5 students:");
        for (int i = 0; i < marks.length; i++) {
            marks[i] = sc.nextInt();
            total += marks[i];
        }

        int highest = marks[0];
        System.out.print("Marks: ");
        for (int mark : marks) {
            System.out.print(mark + " ");
            if (mark > highest) highest = mark;
        }
        System.out.println("\nTotal = " + total);
        System.out.println("Average = " + (double) total / marks.length);
        System.out.println("Highest = " + highest);
        sc.close();
    }
}
